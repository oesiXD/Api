#### Actualización 14 Ene 2022
- npm update
- remove ora and chalk
- add env
- add mysql
- add dialogflow
- add scan qr from webpage
- update route with middleware
- fix send message to story
- external download
- easy deploy heroku
- add support for ubuntu/linux

https://stackoverflow.com/questions/51855169/dialogflow-403-iam-permission-dialogflow-sessions-detectintent